Object.values(document.querySelector('#app > div > div'))[1].children[1]['_owner'].stateNode.state.isRandom = false;
document.getElementsByClassName("styles__randomButton___3CTp0-camelCase")[0].click();
